package br.com.alura.screenmatch.principal;

import br.com.alura.screenmatch.calculos.CalculadoraDeTempo;
import br.com.alura.screenmatch.calculos.FiltroRecomendacao;
import br.com.alura.screenmatch.modelos.Episodio;
import br.com.alura.screenmatch.modelos.Filme;
import br.com.alura.screenmatch.modelos.Serie;

import java.util.ArrayList;

public class Principal {
  public static void main(String[] args) {
    Filme favorito = new Filme("O poderoso chefão", 1970);
    favorito.setDuracaoEmMinutos(180);


    favorito.exibeFichaTecnica();
    favorito.avalia(9);
    favorito.avalia(8);
    favorito.avalia(9);

    System.out.println("Média de avaliações do filme: " + favorito.pegaMedia());

    Serie lost = new Serie("Lost", 2000);
    lost.exibeFichaTecnica();
    lost.setTemporadas(10);
    lost.setEpisodiosPorTemporada(10);
    lost.setMinutosPorEpisodio(50);
    System.out.println("Duração para maratonar Lost: " + lost.getDuracaoEmMinutos());

    Filme outroFilme = new Filme("Avatar", 2023);
    outroFilme.setDuracaoEmMinutos(200);

    CalculadoraDeTempo calculadora = new CalculadoraDeTempo();
    calculadora.inclui(favorito);
    calculadora.inclui(outroFilme);
    calculadora.inclui(lost);
    System.out.println(calculadora.getTempoTotal());

    FiltroRecomendacao filtro = new FiltroRecomendacao();
    filtro.filtra(favorito);

    Episodio episodio = new Episodio();
    episodio.setNumero(1);
    episodio.setSerie(lost);
    episodio.setTotalVisualizacoes(300);
    filtro.filtra(episodio);

    var filmeDoPaulo = new Filme("Dogville", 2003);
    filmeDoPaulo.setDuracaoEmMinutos(200);
    filmeDoPaulo.avalia(10);


    ArrayList<Filme> listaDeFilmes = new ArrayList<>();
    listaDeFilmes.add(filmeDoPaulo);
    listaDeFilmes.add(favorito);
    listaDeFilmes.add(outroFilme);
    System.out.println("Tamanho da lista " + listaDeFilmes.size());
    System.out.println("Primeiro filme " + listaDeFilmes.get(0).getNome());
    System.out.println(listaDeFilmes);
    System.out.println("toString do filme " + listaDeFilmes.get(0).toString());


  }
}
